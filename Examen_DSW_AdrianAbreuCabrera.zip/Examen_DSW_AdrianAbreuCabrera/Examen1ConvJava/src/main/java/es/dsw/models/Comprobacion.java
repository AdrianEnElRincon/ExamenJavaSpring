package es.dsw.models;

import java.io.Serializable;

public class Comprobacion implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private int numero;
	private int cantidad;
	
	public Comprobacion() {}
	
	public Comprobacion(int numero, int cantidad) {
		this.numero = numero;
		this.cantidad = cantidad;
	}
	
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	public int getCantidad() {
		return cantidad;
	}
	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}
	
	
}
