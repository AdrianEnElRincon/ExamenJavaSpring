package es.dsw.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import es.dsw.models.Comprobacion;

@Controller
public class DefaultController {

	@GetMapping("/")
	public String defaultHome(HttpSession session) {
		
		if (session.getAttribute("comprobaciones") == null) session.setAttribute("comprobaciones", new ArrayList<Comprobacion>());
		
		return "default";
	}
	
	@PostMapping("/comprobar")
	@ResponseBody
	public Map<String, String> comprobar(@RequestParam("numero") int numero, @RequestParam("cantidad") int cantidad, HttpSession session) {
		
		Map<String, String> response = new HashMap<>();
		
		@SuppressWarnings("unchecked")
		ArrayList<Comprobacion> comprobaciones = (ArrayList<Comprobacion>) session.getAttribute("comprobaciones");
		
		if (numero == 12123) {
			
			int premio = cantidad * 400_000 / 20;
			
			response.put("check", "winner");
			response.put("message", "Ha sido premiado con " + String.valueOf(premio) + " euros!");
			
		} else {
			response.put("check", "NULL");
			response.put("message", "No ha sido premiado");
		}
		
		comprobaciones.add(new Comprobacion(numero, cantidad));
		
		return response;
		
	}
	
	@GetMapping("/comprobaciones")
	public String comprobaciones(HttpSession session) {
		return "table";
	}
	
}
