$(function() {

	var form = $('#form')
	var inputs = {
		numero: $('[name="numero"]'),
		cantidad: $('[name="cantidad"]')
	}
	var table = $('#table')
	var resultado = $('#resultado')

	form.on('submit', function(event) {

		event.preventDefault()

		var data = {
			numero: inputs.numero.val(),
			cantidad: inputs.cantidad.val()
		}
		
		$.ajax('./comprobar', {
			method: 'POST',
			data: data,
			success: data => handleSuccess(data)
		})

	})


	function handleSuccess(data) {

		if (data.check == 'winner') {
			resultado.text(data.message).css('color', 'lime')
		} else {
			resultado.text(data.message).css('color', 'red')
		}

		refreshTable()
		resetInputs()
	}
	
	function refreshTable() {
		$.ajax('./comprobaciones', {
			success: data => {
				table.html(data)
			}
		})
	}
	
	function resetInputs() {
		inputs.cantidad.val('')
		inputs.numero.val('').focus()
	}

})